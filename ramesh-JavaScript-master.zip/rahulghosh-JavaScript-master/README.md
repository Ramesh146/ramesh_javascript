# rahulghosh-JavaScript
<b>Epam Assignment-13</b>
<br>
<br>
<b> <u>FILE STRUCTURE</u></b><br>
<b>Login Page:</b> index.html<br>
<b>js file:</b> login.js<br>
<b>css file:</b> style.css<br>

